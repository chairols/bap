import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collapsed',
  templateUrl: './collapsed.component.html',
  styleUrls: ['./collapsed.component.css']
})
export class CollapsedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
