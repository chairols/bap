import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-examples',
  templateUrl: './form-examples.component.html',
  styleUrls: ['./form-examples.component.css']
})
export class FormExamplesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
