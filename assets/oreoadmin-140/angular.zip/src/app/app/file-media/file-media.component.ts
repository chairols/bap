import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-media',
  templateUrl: './file-media.component.html',
  styleUrls: ['./file-media.component.css']
})
export class FileMediaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
