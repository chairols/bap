import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-documents',
  templateUrl: './file-documents.component.html',
  styleUrls: ['./file-documents.component.css']
})
export class FileDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
