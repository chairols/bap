import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-images',
  templateUrl: './file-images.component.html',
  styleUrls: ['./file-images.component.css']
})
export class FileImagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
