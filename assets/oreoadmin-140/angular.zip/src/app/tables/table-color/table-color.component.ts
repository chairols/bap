import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table-color',
  templateUrl: './table-color.component.html',
  styleUrls: ['./table-color.component.css']
})
export class TableColorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
